
/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/* Define Global Variables */
var navBar = document.getElementById('navbar__list');
var topBtn = document.getElementById('btn');
var sections = document.querySelectorAll('section');
/* End Define Global Variables */

// Create the Navigation bar 
creatNavBar=()=>
  sections.forEach (function addNavBar(section){
       const sectionName = section.getAttribute('data-nav');
       const sectionId = section.getAttribute('id');
       sectionList = document.createElement('li');
       sectionList.innerHTML = `<a class ="menu__link" data-id="${sectionId}">${sectionName}</a>`;
      navBar.appendChild(sectionList);
   });
   
   creatNavBar(); //call the function

// scroll function
scrollToElement=(event)=>{
  if(event.target.nodeName === 'A'){
      const sectionId = event.target.getAttribute('data-id');
      const section = document.getElementById(sectionId);
      section.scrollIntoView({behavior: "smooth"});
  }
};
// Add listener 
navBar.addEventListener('click', function(event){
  scrollToElement(event)
});


// Viewport function
isInViewport= (elem)=> {
const bounding = elem.getBoundingClientRect();
  return (
      bounding.top >= 0 &&
      bounding.left >= 0 &&
      bounding.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      bounding.right <= (window.innerWidth || document.documentElement.clientWidth)
  )
};

// Active class function
setActiveClass=()=>{
  for (let i=0; i < sections.length; i++){
      if (isInViewport(sections[i])){
          sections[i].classList.add("your-active-class");
      }else{
          sections[i].classList.remove("your-active-class");
      }
  }
};

document.addEventListener('scroll', function(){
  setActiveClass();
});



//Top button function
topClickFun=()=>{
  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
};
// add event listener to get the click action
topBtn.addEventListener("click", topClickFun);
