
# Landing Page Project

## Table of Contents
* about
* Languages
* Implementation 
* How to use  


### about
This file has been converted from a static page to dynamic page using JavaScript and some modifications on the HTML and CSS files to convert into responsive page. 

### Languages
* HTML
* CSS
* JavaScript

### Implementation
* Add a dynamic NavBar to app.js file using JavaScript. 
* Add the 4th section to HTML File.
* Some modifications on CSS file.
* Rewrite README.md file.

### How to use
* Open index.html file.
* choose the section through clicking on the item from the top NavBar.


